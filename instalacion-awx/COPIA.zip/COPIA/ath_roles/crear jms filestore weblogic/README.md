Role Name
=========

Rol para configurar el componente de dominio de Weblogic.

Requirements
------------

El rol utilza un conjunto de variables que deben estar definida

Role Variables
--------------

domain_name: '{{ country_code }}_{{ product_name }}_WLS_{{ ambiente }}'
java_home: '{{ java_root }}\jdk{{ java_version }}'
node_manager_home: '{{ oracle_base_path }}\nodemanager\{{ domain_name }}'
domain:
  data:
    template_name: "Basic WebLogic Server Domain"
    server_start_mode: "prod"
    template_file: '{{ wls_base_path }}\wlserver\common\templates\wls\wls.jar'

Dependencies
------------

Depende del rol "configurar ambiente"

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:



    - hosts: servers
      roles:
         - role: configurar ambiente
         - role: crear dominio weblogic
         vars:
           domain_name: '{{ country_code }}_{{ product_name }}_WLS_{{ ambiente }}'
           java_home: '{{ java_root }}\jdk{{ java_version }}'
           node_manager_home: '{{ oracle_base_path }}\nodemanager\{{ domain_name }}'
           domain:
             data:
               template_name: "Basic WebLogic Server Domain"
               server_start_mode: "prod"
               template_file: '{{ wls_base_path }}\wlserver\common\templates\wls\wls.jar'


License
-------

BSD

Author Information
------------------

Oscar Riveros - BGH Tech Partner
